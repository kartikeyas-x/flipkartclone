import ComingSoon from "./ComingSoon";

const PanCardComponent = () => {
    return <ComingSoon />;
};

export default PanCardComponent;
