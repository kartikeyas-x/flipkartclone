export const furnitureProducts = [
    {
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/bed/d/g/f/-original-imagpprfyygdfnfy.jpeg?q=70",
        name: "Queen Beds",
        offer: "Min 40% off",
        tag: "Top Selling Styles",
    },
    {
        image: "https://rukminim2.flixcart.com/image/832/832/k3yrte80/collapsible-wardrobe/v/a/3/pp-88130-hcx-88130-pp-polypropylene-collapsible-wardrobe-finish-original-imaf744xhgmk6d7r.jpeg?q=70",
        name: "Wardrobes & More",
        offer: "From ₹999",
        tag: "Must Buy",
    },
    {
        image: "https://rukminim2.flixcart.com/image/612/612/kshtxu80/home-temple/5/7/f/22-32-5-1010-nifinity-45-original-imag6fz7agt98hwy.jpeg?q=70",
        name: "Wooden Mandir",
        offer: "From ₹699",
        tag: "Pooja Items",
    },
    {
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/tv-entertainment-unit/n/n/m/-original-imagrtbh4gh4nudw.jpeg?q=70",
        name: "TV Shelves",
        offer: "From ₹1999",
        tag: "Top Selling",
    },
    {
        image: "https://rukminim2.flixcart.com/image/612/612/l1l1rww0/office-study-chair/x/s/u/-original-imagd4emqzrzdeaq.jpeg?q=70",
        name: "Office Chairs",
        offer: "Min 50% off",
        tag: "Cushioned Chairs",
    },
    {
        image: "https://rukminim2.flixcart.com/image/612/612/khcb7gw0/kitchen-trolley/r/z/k/b10-sb-enterpsrize-original-imafxdfdz94yycnz.jpeg?q=70",
        name: "Kitchen Trolleys",
        offer: "Buy 3, Get 10% off",
        tag: "Steel",
    },
];
